from sample_prj.sample_pkg.views import PeugeotView, CarView

PeugeotView().show()
CarView().show()


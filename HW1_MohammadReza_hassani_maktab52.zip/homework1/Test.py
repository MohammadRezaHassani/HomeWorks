# inputStr = list(input())
#
#
# def sumdigit(inputStr):
#     while len(inputStr) > 1:
#         result = sum(map(int, inputStr))
#         inputStr = list(str(result))
#     return int(inputStr[0])
#
#
# print(sumdigit(inputStr))
# ----------------------------------------------------------------------

# number = int(input())
#
#
# def fibonatchi(number):
#     initialList = [1, 1]
#
#     for i in range(number - 2):
#         print(initialList)
#         initialList.append(initialList[-1] + initialList[-2])
#     print(initialList)
#
# fibonatchi(number)

# exercise 1
inputNum = int(input())
for i in range(1, inputNum+1):
    for j in range(1, inputNum+1):
        print(i*j, end=" ")
    print()